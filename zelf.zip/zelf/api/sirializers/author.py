# external imports
from rest_framework import serializers

# internal imports
from author.models import Author
from author.models import Content


class ContentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Content
        exclude = [
            'created_at'
        ]


class AuthorSerializer(serializers.ModelSerializer):

    contents = ContentSerializer(many=True)

    class Meta:
        model = Author
        fields = [
            'author_id',
            'username',
            'contents',
        ]