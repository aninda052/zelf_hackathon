# external imports
from rest_framework.generics import RetrieveAPIView
from rest_framework.views import APIView
from rest_framework.response import Response
from django.db.models import Count

# internal imports
from ..sirializers.author import AuthorSerializer
from author.models import Author, Content
from author.tasks import fetch_author_content



class AuthorApiView(RetrieveAPIView):

    serializer_class = AuthorSerializer
    queryset = Author.objects.all()
    lookup_field = "author_id"


class FetchDateApiView(APIView):

    def get(self, request):
        fetch_author_content.delay()

        return Response({"details": "your request is processing, our system is checking for new data"} )


class DataStatApiView(APIView):

    def get(self, request):
        data = Content.objects.values('platform').annotate(content_count=Count('platform')).order_by("content_count")

        return Response({"stats": list(data)})

