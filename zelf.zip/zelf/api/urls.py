# external imports
from django.urls import path

# internal imports
from .views.author import AuthorApiView, FetchDateApiView,DataStatApiView

urlpatterns = [
    path('author/<int:author_id>/', AuthorApiView.as_view(), name='get_author'),
    path('stats/', DataStatApiView.as_view(), name='get_data_stat'),
    path('fetch-data/', FetchDateApiView.as_view(), name='fetch_data'),
]