## Zelf Hackathon 1.0
This is a simple Django application which will fetch data from 3rd party api and also publish those data using Rest Api

### Overview
Django Rest Framework is used for building api. After fetching data from 3rd party api system 
will store those data on database.

`CELERY` is used for handling schedule/asynchronous job using redis as message broker.

### Prerequisites
To get started with this application, you will need to have the following technologies installed on your local machine:

- python3.8 (Mandatory)
- redis (Mandatory)

Installation
To run the project locally, follow these steps

### Cloning the project
Open your favourite terminal and run billow commands-

```
git clone https://github.com/aninda052/zelf_hackathon.git
cd zelf
```
### Creating .env file
Create a .env file for your environment variable.
```commandline
touch .env
```
 
For running the application just copy billow dummy information and past it to your .env file and save it.

```
DEBUG=True
SECRET_KEY=xy+y*vn5(^^&qp-q5zx@-^@o+v%sw)$y9)o1zskb4y*0khdnaa
ZELF_API_KEY=ed3c6103sk_0277sk_4455sk_b187sk_75f43862ff0a1706933017
CELERY_BROKER_URL=redis://localhost:6379
CELERY_RESULT_BACKEND=redis://localhost:6379

DATABASE=sqlite

```
### Running The Application

You can run the application using runserver command

```
  # create a virtual environment using virtualenv
  virtualenv -p python3.8 venv
      
  # Activate virtual environment
  source venv/bin/activate
      
  # Install all required python packages
  pip install -r requirements.txt
      
  # generate database migration files
  python manage.py makemigrations
      
  # migrate new changes on database
  python manage.py migrate --no-input
      
  # create initial superuser
  DJANGO_SUPERUSER_PASSWORD=admin DJANGO_SUPERUSER_USERNAME=admin DJANGO_SUPERUSER_EMAIL=admin@email.com python manage.py createsuperuser --noinput
      
  # run user server at port 8000
  python manage.py runserver 8000

```
### Run CELERY service
Open another terminal and run billow command. Make sure you are in your project (zelf) directory and you activate your virtual environment (`source venv/bin/activate`)

```
 celery -A zelf worker -B -l info
```

If everything went well, go to http://127.0.0.1:8000 and you'll find the application up and running.

Api
To fetch new data -

```
http://localhost:8000/api/fetch-data/
```

To get the author data -

```
http://localhost:8000/api/author/{author_id}/
```

Example request url
Method - GET

```commandline
http://127.0.0.1:8000/api/author/919301/
```

Response Body -

```commandline
{
    "author_id": 919301,
    "username": "stuffedddd",
    "contents": [
        {
            "id": 1,
            "unique_uuid": "31fca27a-9d67-458d-8e60-5be49a7933db",
            "content": "@pizzahuteg",
            "platform": "instagram",
            "origin_unique_id": "CqiKhfMA0iu",
            "origin_url": "https://instagram.com/p/CqiKhfMA0iu",
            "media_url": "https://nyc3.digitaloceanspaces.com/hellozelf/content/2686819e-aac6-434c-83db-ab02b541699c.jpg",
            "tag_count": 1,
            "like_count": 119778,
            "view_count": 2600000,
            "comment_count": 199,
            "content_created_at": null,
            "author": 1
        }
    ]
}
```

Note: Django REST framework provide self describing APIs. 
So you can just hit the above endpoint from your browser and get the documentation.

Request Body

Go to http://127.0.0.1:8000/admin/ and login with your superuser credential to see your data.