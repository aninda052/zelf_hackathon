from django.db import models

# Create your models here.


class Author(models.Model):
    author_id = models.IntegerField(unique=True)
    username = models.TextField(unique=True)
    created_at = models.DateTimeField(auto_now_add=True)


class Content(models.Model):
    author = models.ForeignKey(Author, on_delete=models.DO_NOTHING, related_name="contents")
    unique_uuid = models.UUIDField(null=True, unique=True)
    content = models.TextField(default="")
    platform = models.TextField(default="")
    origin_unique_id = models.CharField( max_length=30)
    origin_url = models.URLField(max_length=30, null=True)
    media_url = models.URLField(null=True)
    tag_count = models.IntegerField(default=0)
    like_count = models.IntegerField(default=0)
    view_count = models.IntegerField(default=0)
    comment_count = models.IntegerField(default=0)
    content_created_at = models.DateTimeField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
