# external imports
from celery import shared_task, Celery
import requests
import os
import time

# internal imports
from author.models import Author, Content

app = Celery()

def get_response(page_num):
    response = requests.get(
        f"https://hackapi.hellozelf.com/backend/api/v1/contents?page={page_num}",
        headers={
            "x-api-key": os.environ.get("ZELF_API_KEY", "ed3c6103sk_0277sk_4455sk_b187sk_75f43862ff0a1706933017")
        }
    )
    return response

def store_data_in_db(response_data):

    for content in response_data["data"]:
        author = content["author"]
        author, created = Author.objects.get_or_create(
            author_id=author["id"],
            username=author["username"]
        )
        content_data = {
            "author": author,
            "content": content["context"]["main_text"],
            "unique_uuid": content["unique_uuid"],
            "tag_count": content["context"]["tag_count"],
            "platform": content["origin_details"]["origin_platform"],
            "media_url": content["media"]["urls"][0],
            "origin_url": content["origin_details"]["origin_url"],
            "origin_unique_id": content["origin_unique_id"],
            "like_count": content["stats"]["digg_counts"]["likes"]["count"],
            "view_count": content["stats"]["digg_counts"]["views"]["count"],
            "comment_count": content["stats"]["digg_counts"]["comments"]["count"],

        }
        try:
            Content.objects.create(**content_data)
        except:
            pass


def start_fetching():
    page_num = 1
    retry_count = 3
    # content_data = []

    while page_num and retry_count:
        response = get_response(page_num)

        # checking weather it's a successful api call or not
        if response.status_code == 200:
            response_data = response.json()
            page_num = response_data["next"]
            store_data_in_db(response_data)
            retry_count = 3
        else:
            # if api encounter with any error
            # system will try to fetch the same page again after 3 second
            retry_count -= 1
            # sleep for 3 second
            time.sleep(3)

    # insert all content with a bulk create
    # Content.objects.bulk_create(content_data)


@shared_task
def fetch_author_content():
    '''
        this function will fetch all the data from 3rd party api
        system will try to fetch same page 3times if it's dose
        not returned with 200 status code

    '''
    start_fetching()


@app.task
def fetch_author_content_periodically():
    '''
    this is a periodic task
    it'll run everyday at mid night
    '''
    start_fetching()